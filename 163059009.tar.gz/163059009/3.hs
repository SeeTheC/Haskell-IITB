-- One way
--powers x = [ x^p| p<-[0..] ]

-- Efficient way
powers x = 1:[ a*x | a<- (powers x) ]
