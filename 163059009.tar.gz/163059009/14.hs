-- Summand 3 : ( summand 1 ++ [[2]] ) ++ ( summand 2 ++ [[1]] ) + ( [[3]]) 
summands 1 = [[1]]
summands n = [ a:el | a<-[1..(n-1)], el <-(summands (n-a)) ] ++ [[n]]


