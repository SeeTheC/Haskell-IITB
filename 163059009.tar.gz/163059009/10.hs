-- Pascal Triangle : Return List of List up to infinite. Call > take 5 pascal
pascal = [1]:[  [ a+b | (a,b) <- zip (0:x) (x++[0]) ]  | x<- pascal ]
